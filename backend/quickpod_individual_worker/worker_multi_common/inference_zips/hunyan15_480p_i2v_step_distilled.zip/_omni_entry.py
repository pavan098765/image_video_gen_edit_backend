"""Omni runtime entry — hunyan15_480p_i2v_step_distilled (resolves image_input)."""
from typing import Any, Dict


def run_inference(job_id: str, prompt: str, params: Dict[str, Any]) -> str:
    from hunyan15_video_inference import run_inference_hunyan15_i2v
    p = dict(params or {})
    image_input = (
        p.pop("image_input", None)
        or p.pop("image", None)
        or p.pop("init_image", None)
    )
    if not image_input:
        raise ValueError("image_input/init_image is required for hunyuan i2v")
    return run_inference_hunyan15_i2v(job_id, prompt, image_input, p)
