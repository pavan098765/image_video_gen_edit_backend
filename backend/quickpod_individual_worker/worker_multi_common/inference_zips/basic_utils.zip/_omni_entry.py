"""Omni runtime entry — basic_utils (bg_remove / lama_inpaint dispatch)."""
from typing import Any, Dict


def run_inference(job_id: str, prompt: str, params: Dict[str, Any]) -> str:
    mode = str((params or {}).get("mode") or "bg_remove").strip().lower()
    if mode == "lama_inpaint":
        from simple_lama_inpaint import run_inference_simple_lama_inpaint
        return run_inference_simple_lama_inpaint(job_id, prompt, params)
    from bg_remover import run_inference_rmbg
    return run_inference_rmbg(job_id, prompt, params)
